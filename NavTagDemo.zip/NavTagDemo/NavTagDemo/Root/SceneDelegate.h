//
//  SceneDelegate.h
//  NavTagDemo
//
//  Created by Jacob on 2025/3/26.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

