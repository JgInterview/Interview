//
//  AppDelegate.h
//  NavTagDemo
//
//  Created by Jacob on 2025/3/26.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

