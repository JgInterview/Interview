//
//  ViewController.m
//  NavTagDemo
//
//  Created by Jacob on 2025/3/26.
//

#import "ViewController.h"
#import "TopNavView.h"
#import "NSObject+YYModel.h"
#import "NavTabItemModel.h"

@interface ViewController ()

@property (nonatomic, strong) TopNavView *topNavView;

@property (nonatomic, strong) NSMutableArray *dataSource;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self _setUp];
}

- (void)_setUp {
    [self.view addSubview:self.topNavView];
    [self.topNavView fillData:self.dataSource];
}

#pragma mark - Getter

- (TopNavView *)topNavView {
    if (!_topNavView) {
        _topNavView = [[TopNavView alloc] initWithFrame:CGRectMake((CGRectGetWidth(self.view.frame) - 310)/2.f, 80, 310, 200)];
    }
    return _topNavView;
}

- (NSMutableArray *)dataSource {
    if (!_dataSource) {
        NSDictionary *data1 = @{@"name":@"导航一", @"labelText":@"中优先",  @"labelPriority":@(1)};
        NSDictionary *data2 = @{@"name":@"导航二", @"labelText":@"高优先",  @"labelPriority":@(0)};
        NSDictionary *data3 = @{@"name":@"导航三", @"labelText":@"低优先",  @"labelPriority":@(2)};
        NSDictionary *data4 = @{@"name":@"导航四", @"labelText":@"极低优先", @"labelPriority":@(3)};
        _dataSource = [NSMutableArray arrayWithObjects:[NavTabItemModel yy_modelWithJSON:data1],
                                                       [NavTabItemModel yy_modelWithJSON:data2],
                                                       [NavTabItemModel yy_modelWithJSON:data3],
                                                       [NavTabItemModel yy_modelWithJSON:data4],
                                                       nil];
    }
    return _dataSource;
}



@end
