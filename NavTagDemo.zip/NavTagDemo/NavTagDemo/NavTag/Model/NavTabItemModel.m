//
//  NavTabItemModel.m
//  NavTagDemo
//
//  Created by Jacob on 2025/3/26.
//

#import "NavTabItemModel.h"

@implementation NavTabItemModel

@end
