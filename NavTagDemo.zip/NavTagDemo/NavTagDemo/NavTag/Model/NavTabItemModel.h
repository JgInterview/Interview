//
//  NavTabItemModel.h
//  NavTagDemo
//
//  Created by Jacob on 2025/3/26.
//

#import <Foundation/Foundation.h>

@interface NavTabItemModel : NSObject

@property (nonatomic, copy) NSString *name; 
@property (nonatomic, assign) NSInteger labelPriority; // 角标优先级(数值越大,优先级越低)
@property (nonatomic, copy) NSString *labelText; // 角标文案

@property (nonatomic, assign) BOOL isValidTag;

@end

