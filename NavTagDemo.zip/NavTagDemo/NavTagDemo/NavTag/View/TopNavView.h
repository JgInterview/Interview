//
//  TopNavView.h
//  NavTagDemo
//
//  Created by Jacob on 2025/3/26.
//

#import <UIKit/UIKit.h>

@interface TopNavView : UIView

- (void)fillData: (NSArray *)dataSource;

@end

