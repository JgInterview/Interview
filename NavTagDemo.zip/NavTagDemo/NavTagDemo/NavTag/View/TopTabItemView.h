//
//  TopTabItemView.h
//  NavTagDemo
//
//  Created by Jacob on 2025/3/26.
//

#import <UIKit/UIKit.h>

@class NavTabItemModel;
@interface TopTabItemView : UIView

- (void)fillData: (NavTabItemModel *)model;

@end

