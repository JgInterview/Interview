//
//  TopTabItemView.m
//  NavTagDemo
//
//  Created by Jacob on 2025/3/26.
//

#import "TopTabItemView.h"
#import "NavTabItemModel.h"

@interface TopTabItemView ()

@property (nonatomic, strong) UIView *bgCorView;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *tagLabel;

@end

@implementation TopTabItemView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.bgCorView];
        [self addSubview:self.nameLabel];
        [self addSubview:self.tagLabel];
        [self setColors];
    }
    return self;
}

- (void)fillData: (NavTabItemModel *)model {
    if (!model) {
        self.nameLabel.text = nil;
        self.tagLabel.hidden = YES;
        return;
    }
    
    self.nameLabel.text = model.name;
    self.tagLabel.text = model.labelText;
    self.tagLabel.hidden = !(model.labelText.length > 0);
}

#pragma mark - Getter

- (UIView *)bgCorView {
    if (!_bgCorView) {
        _bgCorView = [[UIView alloc] initWithFrame:self.bounds];
        _bgCorView.layer.borderWidth = 2.f;
        _bgCorView.layer.borderColor = [UIColor colorWithRed:(223/255.f) green:(34/255.f) blue:(31/255.f) alpha:0.9].CGColor;
        _bgCorView.layer.cornerRadius = 4.f;
    }
    return _bgCorView;
}

- (UILabel *)nameLabel {
    if (!_nameLabel) {
        _nameLabel = [[UILabel alloc] initWithFrame:self.bounds];
        _nameLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _nameLabel;
}

- (UILabel *)tagLabel {
    if (!_tagLabel) {
        _tagLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.frame.size.width - 30, -8, 45, 18)];
        _tagLabel.textAlignment = NSTextAlignmentCenter;
        _tagLabel.layer.masksToBounds = YES;
        _tagLabel.layer.cornerRadius = 9;
        _tagLabel.layer.borderWidth = 0.5f;
        _tagLabel.font = [UIFont systemFontOfSize:10.f];
        _tagLabel.adjustsFontSizeToFitWidth = YES;
    }
    return _tagLabel;
}

- (void)setColors {
    self.tagLabel.textColor = [UIColor whiteColor];
    self.tagLabel.backgroundColor = [UIColor colorWithRed:(223/255.f) green:(34/255.f) blue:(31/255.f) alpha:1];
    self.tagLabel.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.6].CGColor;
}

@end
