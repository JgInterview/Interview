//
//  TopNavView.m
//  NavTagDemo
//
//  Created by Jacob on 2025/3/26.
//

#import "TopNavView.h"
#import "NavTabItemModel.h"
#import "TopTabItemView.h"

// 可同时展示角标个数配置
#define kTopNavViewTagLimit  4

@interface TopNavView ()

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) NSArray *dataArr;

@end

@implementation TopNavView

- (void)fillData: (NSArray *)dataSource {
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [self addSubview:self.titleLabel];
    [self processData:dataSource];
    [self fillItems];
}

- (void)processData: (NSArray *)dataSource {
    // TODO: 完成角标按优先级展示,可配置最多展示角标个数的功能
    
    
    self.dataArr = dataSource;
}

- (void)fillItems {
    CGFloat itemW = 60;
    CGFloat itemH = 40;
    for (int i = 0; i < self.dataArr.count; i ++) {
        TopTabItemView *item = [[TopTabItemView alloc] initWithFrame:CGRectMake(20 + (itemW + 15) * i, 40, itemW, itemH)];
        [self addSubview:item];
        
        NavTabItemModel *model = self.dataArr[i];
        [item fillData:model];
    }
}

#pragma mark - Getter

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, 20)];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.font = [UIFont systemFontOfSize:11.f];
        _titleLabel.textColor = [UIColor orangeColor];
        _titleLabel.text = [NSString stringWithFormat:@"可同时展示角标:%ld",(long)kTopNavViewTagLimit];
    }
    return _titleLabel;
}

@end
